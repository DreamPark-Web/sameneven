'use client'

import { useState } from 'react'
import { useInsight } from '@/lib/insight-context'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

export default function Topbar({ activePage, setActivePage }: { activePage: string; setActivePage: (p: string) => void }) {
  const { household, syncState, currentUser, members, data, saveData } = useInsight()
  const router = useRouter()
  const supabase = createClient()

  const [showAccount, setShowAccount] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [accountName, setAccountName] = useState('')
  const [insightName, setInsightName] = useState('')
  const [copied, setCopied] = useState(false)

  const syncColor = syncState === 'saving' ? '#d4a017' : syncState === 'error' ? '#e05050' : syncState === 'live' ? '#00c2ff' : '#4caf82'
  const syncLabel = syncState === 'saving' ? 'Opslaan...' : syncState === 'error' ? 'Fout bij opslaan' : syncState === 'live' ? 'Live bijgewerkt ✓' : 'Gesynchroniseerd'

  const myMember = members.find((m: any) => m.user_id === currentUser?.id)
  const displayName = myMember?.display_name || currentUser?.user_metadata?.full_name || 'Gebruiker'
  const avatarUrl = myMember?.avatar_url || currentUser?.user_metadata?.avatar_url
  const initials = displayName.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase()

  function openAccount() {
    setAccountName(displayName)
    setShowAccount(true)
  }

  function openSettings() {
    setInsightName(household?.name || '')
    setShowSettings(true)
  }

  async function saveAccount() {
    if (!accountName.trim()) return
    await supabase.from('profiles').upsert({ id: currentUser.id, display_name: accountName.trim() }, { onConflict: 'id' })
    setShowAccount(false)
    router.refresh()
  }

  async function saveInsightName() {
    if (!insightName.trim()) return
    await supabase.from('households').update({ name: insightName.trim() }).eq('id', household.id)
    setShowSettings(false)
    router.refresh()
  }

  async function logout() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  function copyInvite() {
    const url = `${window.location.origin}?invite=${household?.invite_code || ''}`
    navigator.clipboard.writeText(url)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function saveN1(val: string) { saveData({ ...data, names: { ...data.names, user1: val } }) }
  function saveN2(val: string) { saveData({ ...data, names: { ...data.names, user2: val } }) }

  const modal: React.CSSProperties = { background: 'var(--s1)', border: '1px solid var(--border)', borderRadius: 12, padding: 28, width: '100%', maxWidth: 460, position: 'relative', maxHeight: '90vh', overflowY: 'auto' }
  const modalBg: React.CSSProperties = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,.75)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }
  const modalLabel: React.CSSProperties = { fontSize: 11, fontWeight: 600, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 6, display: 'block' }
  const modalInp: React.CSSProperties = { width: '100%', background: 'var(--s2)', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text)', padding: '9px 11px', fontSize: 13, fontFamily: 'var(--font-body)', marginBottom: 14, boxSizing: 'border-box', outline: 'none' }
  const modalSection: React.CSSProperties = { background: 'var(--s2)', borderRadius: 8, padding: '14px 16px', marginBottom: 14 }
  const btnPrimary: React.CSSProperties = { background: 'var(--accent)', color: '#0a0a0a', border: 'none', borderRadius: 6, padding: '9px 16px', fontSize: 12, fontFamily: 'var(--font-body)', fontWeight: 700, cursor: 'pointer', letterSpacing: '.04em', textTransform: 'uppercase' }
  const btnGhost: React.CSSProperties = { background: 'transparent', color: 'var(--muted2)', border: '1px solid var(--border)', borderRadius: 6, padding: '9px 16px', fontSize: 12, fontFamily: 'var(--font-body)', fontWeight: 600, cursor: 'pointer' }

  return (
    <>
      <header style={{
        background: 'var(--s1)', borderBottom: '1px solid var(--border)',
        height: 60, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 24px 0 12px', position: 'fixed', top: 0, left: 0, right: 0, zIndex: 200, gap: 16
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flex: 1, minWidth: 0 }}>
          <button onClick={() => router.push('/picker')} style={{ background: 'transparent', border: '1px solid transparent', color: 'var(--muted)', cursor: 'pointer', fontSize: 18, padding: 0, width: 32, height: 40, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>←</button>
          <div style={{ fontSize: 19, fontWeight: 700, fontFamily: 'var(--font-heading)', letterSpacing: '-.3px', whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', height: 40 }}>
            <span style={{ color: 'var(--text)' }}>Samen</span>&nbsp;<span style={{ color: 'var(--accent)' }}>Even</span>
          </div>
          {household && <span style={{ fontSize: 12, color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 240 }}>{household.name}</span>}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, paddingRight: 4 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: syncColor, flexShrink: 0, transition: 'background .3s' }} />
            <span style={{ fontSize: 10, color: 'var(--muted)', whiteSpace: 'nowrap' }}>{syncLabel}</span>
          </div>

          {/* Gear / settings */}
          <button onClick={openSettings} style={{ width: 40, height: 40, background: 'transparent', border: '1px solid var(--border)', borderRadius: 10, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', flexShrink: 0, transition: '.15s' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>
            </svg>
          </button>

          {/* Avatar */}
          <button onClick={openAccount} style={{ width: 40, height: 40, borderRadius: '50%', border: '1px solid var(--border)', background: 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 2, cursor: 'pointer', overflow: 'hidden', transition: 'border-color .15s, box-shadow .15s, transform .15s', flexShrink: 0 }}>
            {avatarUrl ? (
              <img src={avatarUrl} style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} alt={displayName} />
            ) : (
              <div style={{ width: '100%', height: '100%', borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#0a0a0a' }}>{initials}</div>
            )}
          </button>
        </div>
      </header>

      {/* Account Modal */}
      {showAccount && (
        <div style={modalBg} onClick={e => { if (e.target === e.currentTarget) setShowAccount(false) }}>
          <div style={modal}>
            <button onClick={() => setShowAccount(false)} style={{ position: 'absolute', top: 14, right: 14, background: 'none', border: 'none', color: 'var(--muted)', fontSize: 18, cursor: 'pointer', lineHeight: 1, padding: 4 }}>×</button>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 20, fontFamily: 'var(--font-heading)' }}>Mijn account</div>

            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 20 }}>
              <div style={{ width: 60, height: 60, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 700, color: '#0a0a0a', overflow: 'hidden' }}>
                {avatarUrl ? <img src={avatarUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} alt="" /> : initials}
              </div>
            </div>

            <label style={modalLabel}>Jouw naam</label>
            <input style={modalInp} type="text" value={accountName} onChange={e => setAccountName(e.target.value)} />

            <label style={modalLabel}>E-mailadres</label>
            <input style={{ ...modalInp, opacity: 0.6 }} type="email" value={currentUser?.email || ''} disabled />

            <div style={modalSection}>
              <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 10 }}>Persoonlijk</div>
              <div style={{ fontSize: 11, color: 'var(--muted2)', lineHeight: 1.6 }}>Je Google-naam wordt als eerste gebruikt. Hier kun je die naam aanpassen voor Samen Even.</div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <button onClick={logout} style={{ background: 'rgba(200,60,60,.1)', color: 'var(--danger)', border: '1px solid rgba(200,60,60,.2)', borderRadius: 5, padding: '11px 16px', fontSize: 11, fontFamily: 'var(--font-body)', fontWeight: 600, cursor: 'pointer' }}>Uitloggen</button>
              <button onClick={saveAccount} style={{ ...btnPrimary, width: '100%' }}>Opslaan</button>
            </div>
          </div>
        </div>
      )}

      {/* Insight Settings Modal */}
      {showSettings && (
        <div style={modalBg} onClick={e => { if (e.target === e.currentTarget) setShowSettings(false) }}>
          <div style={modal}>
            <button onClick={() => setShowSettings(false)} style={{ position: 'absolute', top: 14, right: 14, background: 'none', border: 'none', color: 'var(--muted)', fontSize: 18, cursor: 'pointer', lineHeight: 1, padding: 4 }}>×</button>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 20, fontFamily: 'var(--font-heading)' }}>Insight-instellingen</div>

            <div style={modalSection}>
              <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 10 }}>Insight</div>
              <label style={modalLabel}>Naam van de Insight</label>
              <input style={modalInp} type="text" value={insightName} onChange={e => setInsightName(e.target.value)} />
            </div>

            <div style={modalSection}>
              <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 10 }}>Namen</div>
              <label style={modalLabel}>Naam gebruiker 1</label>
              <input style={modalInp} type="text" defaultValue={data.names?.user1} onBlur={e => saveN1(e.target.value)} />
              <label style={modalLabel}>Naam gebruiker 2</label>
              <input style={modalInp} type="text" defaultValue={data.names?.user2} onBlur={e => saveN2(e.target.value)} />
            </div>

            <div style={modalSection}>
              <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 10 }}>Uitnodigingslink</div>
              <div style={{ flex: 1, background: 'var(--s3)', borderRadius: 5, padding: '8px 10px', fontSize: 11, color: 'var(--accent)', letterSpacing: '.04em', wordBreak: 'break-all', marginBottom: 10 }}>
                {typeof window !== 'undefined' ? `${window.location.origin}?invite=${household?.invite_code || ''}` : ''}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
                <button onClick={copyInvite} style={btnGhost}>{copied ? 'Gekopieerd!' : 'Kopieer'}</button>
                <button onClick={() => { const url = `${window.location.origin}?invite=${household?.invite_code || ''}`; window.open(`https://wa.me/?text=${encodeURIComponent(url)}`) }} style={btnGhost}>WhatsApp</button>
                <button onClick={() => { const url = `${window.location.origin}?invite=${household?.invite_code || ''}`; window.location.href = `mailto:?subject=Samen Even uitnodiging&body=${encodeURIComponent(url)}` }} style={btnGhost}>E-mail</button>
              </div>
            </div>

            <button onClick={saveInsightName} style={{ ...btnPrimary, width: '100%' }}>Opslaan</button>
          </div>
        </div>
      )}
    </>
  )
}